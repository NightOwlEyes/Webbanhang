<?php include 'app/views/shares/header.php'; ?>

<div class="container mt-5">
    <div class="card shadow p-4">
        <h2 class="text-center text-success">🌿 Thêm cây cảnh mới</h2>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['error']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <form id="add-product-form">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="name" class="form-label">🌱 Tên cây:</label>
                        <input type="text" id="name" name="name" class="form-control" placeholder="Nhập tên cây cảnh" required>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">📝 Mô tả:</label>
                        <textarea id="description" name="description" class="form-control" rows="4" placeholder="Nhập mô tả về cây cảnh" required></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="price" class="form-label">💰 Giá:</label>
                        <input type="number" id="price" name="price" class="form-control" step="0.01" placeholder="Nhập giá cây cảnh" required>
                    </div>

                    <div class="mb-3">
                        <label for="category_id" class="form-label">📂 Danh mục:</label>
                        <select id="category_id" name="category_id" class="form-control" required>
                            <option value="" disabled selected>Chọn danh mục</option>
                        </select>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="care_guide" class="form-label">🔍 Hướng dẫn chăm sóc:</label>
                        <textarea id="care_guide" name="care_guide" class="form-control" rows="3" placeholder="Nhập hướng dẫn chăm sóc cây"></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="sunlight" class="form-label">☀️ Yêu cầu ánh sáng:</label>
                        <input type="text" id="sunlight" name="sunlight" class="form-control">
                    </div>
                    
                    <div class="mb-3">
                        <label for="water" class="form-label">💧 Yêu cầu nước:</label>
                        <input type="text" id="water" name="water" class="form-control">
                    </div>
                    
                    <div class="mb-3">
                        <label for="size" class="form-label">📏 Kích thước:</label>
                        <input type="text" id="size" name="size" class="form-control">
                    </div>
                    
                    <div class="mb-3">
                        <label for="stock" class="form-label">📦 Số lượng tồn kho:</label>
                        <input type="number" id="stock" name="stock" class="form-control" min="0" value="10">
                    </div>
                </div>
            </div>
            
            <div class="mb-3">
                <label for="image" class="form-label">🖼 Hình ảnh:</label>
                <input type="file" id="image" name="image" class="form-control" onchange="previewImage(event)">
                <small class="text-muted">Chỉ chấp nhận các định dạng: JPG, JPEG, PNG, GIF, WEBP. Kích thước tối đa: 10MB.</small>
                <div class="mt-3 text-center">
                    <img id="preview" src="" alt="Xem trước hình ảnh" class="img-thumbnail d-none" style="max-width: 200px;">
                </div>
            </div>

            <div class="text-center">
                <button type="submit" class="btn btn-success"><i class="fas fa-leaf"></i> Thêm cây cảnh</button>
                <a href="/nightowleyes/Product/list" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Quay lại danh sách</a>
            </div>
        </form>
    </div>
</div>

<script>
    function previewImage(event) {
        let reader = new FileReader();
        reader.onload = function() {
            let imgElement = document.getElementById('preview');
            imgElement.src = reader.result;
            imgElement.classList.remove('d-none');
        }
        reader.readAsDataURL(event.target.files[0]);
    }
    
    document.addEventListener("DOMContentLoaded", function() {
        fetch('/nightowleyes/api/category')
            .then(response => response.json())
            .then(data => {
                const categorySelect = document.getElementById('category_id');
                data.forEach(category => {
                    const option = document.createElement('option');
                    option.value = category.id;
                    option.textContent = category.name;
                    categorySelect.appendChild(option);
                });
            });

        document.getElementById('add-product-form').addEventListener('submit', function(event) {
            event.preventDefault();
            const formData = new FormData(this);
            const jsonData = {};
            formData.forEach((value, key) => {
                jsonData[key] = value;
            });
            fetch('/nightowleyes/api/product', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(jsonData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.message === 'Product created successfully') {
                    location.href = '/nightowleyes/Product';
                } else {
                    alert('Thêm sản phẩm thất bại');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Lỗi: Không thể thêm sản phẩm.');
            });
        });
    });
</script>

<?php include 'app/views/shares/footer.php'; ?>

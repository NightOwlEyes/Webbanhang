<?php include 'app/views/shares/header.php'; ?>

<div class="container mt-4">
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['success']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <h1 class="text-center mb-4">Danh sách sản phẩm</h1>

    <a href="/nightowleyes/Product/add" class="btn btn-success mb-2">
        <i class="fas fa-plus"></i> Thêm sản phẩm mới
    </a>

    <div class="row" id="product-list">
        <!-- Danh sách sản phẩm sẽ được tải từ API và hiển thị tại đây -->
    </div>
</div>

<style>
.product-card {
    transition: transform 0.2s;
}
.product-card:hover {
    transform: translateY(-5px);
}
.product-image {
    height: 200px;
    object-fit: cover;
    width: 100%;
}
</style>

<?php include 'app/views/shares/footer.php'; ?>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const token = localStorage.getItem('jwtToken');
    const userData = JSON.parse(localStorage.getItem('userData') || '{}');
    const isAdmin = userData.role === 'admin';

    if (!token) {
        alert('Vui lòng đăng nhập');
        location.href = '/nightowleyes/account/login';
        return;
    }

    fetch('/nightowleyes/api/product', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        }
    })
    .then(response => response.json())
    .then(data => {
        const productList = document.getElementById('product-list');
        data.forEach(product => {
            const productCard = document.createElement('div');
            productCard.className = 'col-md-4 mb-4';
            productCard.innerHTML = `
                <div class="card h-100 product-card shadow-sm">
                    <img src="/nightowleyes/${product.image || 'uploads/default.jpg'}" 
                         class="card-img-top product-image" 
                         alt="${product.name}"
                         onerror="this.src='/nightowleyes/uploads/default.jpg'">
                    <div class="card-body">
                        <h5 class="card-title">
                            <a href="/nightowleyes/Product/show/${product.id}" class="text-decoration-none">
                                ${product.name}
                            </a>
                        </h5>
                        <p class="card-text text-truncate">${product.description}</p>
                        <p class="card-text">
                            <strong>Giá:</strong> 
                            <span class="text-danger">${product.price.toLocaleString('vi-VN')} VND</span>
                        </p>
                        <p class="card-text">
                            <small class="text-muted">Danh mục: ${product.category_name}</small>
                        </p>
                        <div class="d-flex justify-content-between align-items-center">
                            ${isAdmin ? `
                                <div class="btn-group">
                                    <button onclick="editProduct(${product.id})" class="btn btn-warning btn-sm">
                                        <i class="fas fa-edit"></i> Sửa
                                    </button>
                                    <button class="btn btn-danger btn-sm" onclick="deleteProduct(${product.id})">
                                        <i class="fas fa-trash"></i> Xóa
                                    </button>
                                </div>
                            ` : ''}
                            <span class="badge bg-${product.stock > 0 ? 'success' : 'danger'}">
                                ${product.stock > 0 ? 'Còn hàng' : 'Hết hàng'}
                            </span>
                        </div>
                    </div>
                </div>
            `;
            productList.appendChild(productCard);
        });
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Có lỗi xảy ra khi tải danh sách sản phẩm');
    });
});

function editProduct(id) {
    const token = localStorage.getItem('jwtToken');
    const userData = JSON.parse(localStorage.getItem('userData') || '{}');
    
    if (userData.role !== 'admin') {
        alert('Bạn không có quyền sửa sản phẩm');
        return;
    }
    
    window.location.href = `/nightowleyes/Product/edit/${id}`;
}

function deleteProduct(id) {
    if (confirm('Bạn có chắc chắn muốn xóa sản phẩm này?')) {
        const token = localStorage.getItem('jwtToken');
        
        fetch(`/nightowleyes/api/product/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': 'Bearer ' + token
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Product deleted successfully') {
                location.reload();
            } else {
                alert('Xóa sản phẩm thất bại');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Có lỗi xảy ra khi xóa sản phẩm');
        });
    }
}
</script>